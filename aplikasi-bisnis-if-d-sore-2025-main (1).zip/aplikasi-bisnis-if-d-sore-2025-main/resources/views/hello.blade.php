<html>
    <body>
        <h1>Hello World</h1>

        <ul>
            <li><a href="{{ route('hello.nama', 'Budi') }}">Budi</a></li>
            <li><a href="{{ route('hello.nama', 'Agus') }}">Agus</a></li>
        </ul>
    </body>
</html>
