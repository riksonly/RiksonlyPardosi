<html>
    <body>
        <h1>Hello {{ $nama }}</h1>
        <a href="{{ route('hello.index') }}">Kembali ke index</a>
    </body>
</html>
